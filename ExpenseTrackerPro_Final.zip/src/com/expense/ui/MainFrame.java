package com.expense.ui;

import com.expense.dao.ExpenseDAO;
import com.expense.model.Expense;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

// JFreeChart imports
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.category.DefaultCategoryDataset;

// PDFBox imports
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

/**
 * Main Swing frame for Expense Tracker.
 */
public class MainFrame extends JFrame {

    private final ExpenseDAO dao = new ExpenseDAO();

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new Object[]{"ID", "Category", "Amount", "Timestamp", "Note"}, 0
    );
    private final JTable table = new JTable(tableModel);

    private final JComboBox<String> categoryBox = new JComboBox<>(
            new String[]{"Saving", "Spend", "Food", "Travel", "Other"}
    );
    private final JTextField amountField = new JTextField(8);
    private final JTextField noteField = new JTextField(12);

    public MainFrame() {
        setTitle("Expense Tracker - Swing + SQLite + JFreeChart + PDFBox");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        buildTopPanel();
        add(new JScrollPane(table), BorderLayout.CENTER);

        loadTable();
    }

    private void buildTopPanel() {
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));

        top.add(new JLabel("Category:"));
        top.add(categoryBox);
        top.add(new JLabel("Amount:"));
        top.add(amountField);
        top.add(new JLabel("Note:"));
        top.add(noteField);

        JButton addBtn = new JButton("Add");
        JButton refreshBtn = new JButton("Refresh");
        JButton pieBtn = new JButton("Pie Chart");
        JButton barBtn = new JButton("Bar Chart");
        JButton csvBtn = new JButton("Export CSV");
        JButton pdfBtn = new JButton("Export PDF");

        addBtn.addActionListener(e -> onAdd());
        refreshBtn.addActionListener(e -> loadTable());
        pieBtn.addActionListener(e -> onShowPieChart());
        barBtn.addActionListener(e -> onShowBarChart());
        csvBtn.addActionListener(e -> onExportCsv());
        pdfBtn.addActionListener(e -> onExportPdf());

        top.add(addBtn);
        top.add(refreshBtn);
        top.add(pieBtn);
        top.add(barBtn);
        top.add(csvBtn);
        top.add(pdfBtn);

        add(top, BorderLayout.NORTH);
    }

    private void onAdd() {
        try {
            String category = (String) categoryBox.getSelectedItem();
            String amtText = amountField.getText().trim();
            if (amtText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter an amount.");
                return;
            }
            double amount = Double.parseDouble(amtText);
            if (amount <= 0) {
                JOptionPane.showMessageDialog(this, "Amount must be positive.");
                return;
            }
            String note = noteField.getText().trim();

            Expense e = new Expense(category, amount, LocalDateTime.now(), note);
            dao.insert(e);

            JOptionPane.showMessageDialog(this, "Expense added.");
            amountField.setText("");
            noteField.setText("");

            loadTable();
        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(this, "Invalid amount.");
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error adding expense: " + ex.getMessage());
        }
    }

    private void loadTable() {
        try {
            List<Expense> expenses = dao.getAll();
            tableModel.setRowCount(0);
            for (Expense e : expenses) {
                tableModel.addRow(new Object[]{
                        e.getId(),
                        e.getCategory(),
                        e.getAmount(),
                        e.getTimestamp().toString(),
                        e.getNote()
                });
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading data: " + ex.getMessage());
        }
    }

    // ---------- Analytics ----------

    private void onShowPieChart() {
        int[] ym = askYearMonth();
        if (ym == null) return;

        int year = ym[0];
        int month = ym[1];

        try {
            List<ExpenseDAO.MonthlySummary> list = dao.getMonthlySummary(year, month);
            if (list.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No data for that month.");
                return;
            }

            DefaultPieDataset dataset = new DefaultPieDataset();
            for (ExpenseDAO.MonthlySummary ms : list) {
                dataset.setValue(ms.category + " (₹" + String.format("%.2f", ms.total) + ")", ms.total);
            }

            JFreeChart chart = ChartFactory.createPieChart(
                    "Monthly Expenses " + month + "/" + year,
                    dataset,
                    true,
                    true,
                    false
            );

            ChartPanel panel = new ChartPanel(chart);
            JDialog dialog = new JDialog(this, "Pie Chart - Monthly Expenses", false);
            dialog.setContentPane(panel);
            dialog.setSize(600, 400);
            dialog.setLocationRelativeTo(this);
            dialog.setVisible(true);

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error building chart: " + ex.getMessage());
        }
    }

    private void onShowBarChart() {
        int[] ym = askYearMonth();
        if (ym == null) return;

        int year = ym[0];
        int month = ym[1];

        try {
            ExpenseDAO.SavingSpendingSummary ss = dao.getSavingVsSpending(year, month);
            if (ss.saving == 0 && ss.spending == 0) {
                JOptionPane.showMessageDialog(this, "No Saving/Spend data for that month.");
                return;
            }

            DefaultCategoryDataset dataset = new DefaultCategoryDataset();
            dataset.addValue(ss.saving, "Amount", "Saving");
            dataset.addValue(ss.spending, "Amount", "Spend");

            JFreeChart chart = ChartFactory.createBarChart(
                    "Saving vs Spending " + month + "/" + year,
                    "Type",
                    "Amount",
                    dataset
            );

            ChartPanel panel = new ChartPanel(chart);
            JDialog dialog = new JDialog(this, "Bar Chart - Saving vs Spending", false);
            dialog.setContentPane(panel);
            dialog.setSize(600, 400);
            dialog.setLocationRelativeTo(this);
            dialog.setVisible(true);

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error building chart: " + ex.getMessage());
        }
    }

    private int[] askYearMonth() {
        String yearStr = JOptionPane.showInputDialog(this, "Enter year (YYYY):", LocalDateTime.now().getYear());
        if (yearStr == null) return null;
        String monthStr = JOptionPane.showInputDialog(this, "Enter month (1-12):", LocalDateTime.now().getMonthValue());
        if (monthStr == null) return null;

        try {
            int year = Integer.parseInt(yearStr.trim());
            int month = Integer.parseInt(monthStr.trim());
            if (month < 1 || month > 12) throw new NumberFormatException("Invalid month");
            return new int[]{year, month};
        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(this, "Invalid year or month.");
            return null;
        }
    }

    // ---------- Export CSV ----------

    private void onExportCsv() {
        File dir = new File("exports");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        File out = new File(dir, "expenses.csv");

        try (PrintWriter pw = new PrintWriter(new FileWriter(out))) {
            List<Expense> expenses = dao.getAll();

            pw.println("id,category,amount,timestamp,note");
            for (Expense e : expenses) {
                String safeNote = e.getNote() == null ? "" : e.getNote().replace(""", """");
                // Wrap note in quotes to allow commas
                pw.printf("%d,%s,%.2f,%s,"%s"%n",
                        e.getId(),
                        e.getCategory(),
                        e.getAmount(),
                        e.getTimestamp().toString(),
                        safeNote
                );
            }

            JOptionPane.showMessageDialog(this, "CSV exported to: " + out.getPath());
        } catch (IOException io) {
            io.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error exporting CSV: " + io.getMessage());
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error exporting CSV: " + ex.getMessage());
        }
    }

    // ---------- Export PDF (PDFBox) ----------

    private void onExportPdf() {
        File dir = new File("exports");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        File out = new File(dir, "expenses.pdf");

        try {
            List<Expense> expenses = dao.getAll();
            if (expenses.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No data to export.");
                return;
            }

            PDDocument doc = new PDDocument();
            PDPage page = new PDPage(PDRectangle.A4);
            doc.addPage(page);

            PDPageContentStream content = new PDPageContentStream(doc, page);
            content.setFont(PDType1Font.HELVETICA_BOLD, 14);
            content.beginText();
            content.newLineAtOffset(50, 800);
            content.showText("Expense Report");
            content.newLineAtOffset(0, -20);
            content.setFont(PDType1Font.HELVETICA, 10);
            content.showText("Generated at: " + LocalDateTime.now().toString());
            content.newLineAtOffset(0, -30);

            float y = 750;
            float lineHeight = 14;
            String header = String.format("%-5s %-10s %-10s %-22s %-40s",
                    "ID", "Category", "Amount", "Timestamp", "Note");
            content.showText(header);
            content.newLineAtOffset(0, -lineHeight);
            y -= lineHeight;

            for (Expense e : expenses) {
                if (y < 50) {
                    content.endText();
                    content.close();
                    page = new PDPage(PDRectangle.A4);
                    doc.addPage(page);
                    content = new PDPageContentStream(doc, page);
                    content.setFont(PDType1Font.HELVETICA, 10);
                    content.beginText();
                    content.newLineAtOffset(50, 800);
                    y = 800;
                }

                String note = e.getNote() == null ? "" : e.getNote();
                if (note.length() > 35) {
                    note = note.substring(0, 32) + "...";
                }
                String line = String.format("%-5d %-10s %-10.2f %-22s %-40s",
                        e.getId(),
                        e.getCategory(),
                        e.getAmount(),
                        e.getTimestamp().toString(),
                        note);
                content.showText(line);
                content.newLineAtOffset(0, -lineHeight);
                y -= lineHeight;
            }

            content.endText();
            content.close();

            doc.save(out);
            doc.close();

            JOptionPane.showMessageDialog(this, "PDF exported to: " + out.getPath());
        } catch (IOException io) {
            io.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error exporting PDF: " + io.getMessage());
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error exporting PDF: " + ex.getMessage());
        }
    }
}

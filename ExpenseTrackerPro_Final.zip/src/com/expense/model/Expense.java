package com.expense.model;

import java.time.LocalDateTime;

/**
 * Expense entity representing a single row in the expenses table.
 */
public class Expense {
    private int id;
    private String category;
    private double amount;
    private LocalDateTime timestamp;
    private String note;

    public Expense() {}

    public Expense(String category, double amount, LocalDateTime timestamp, String note) {
        this.category = category;
        this.amount = amount;
        this.timestamp = timestamp;
        this.note = note;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    public String getNote() { return note; }
    public void setNote(String note) { this.note = note; }
}

package com.expense.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Handles SQLite connection and table creation.
 */
public class DatabaseManager {

    // SQLite DB file relative path
    private static final String URL = "jdbc:sqlite:data/expenses.db";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL);
    }

    public static void initializeDatabase() {
        String sql = """
            CREATE TABLE IF NOT EXISTS expenses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                amount REAL NOT NULL,
                timestamp TEXT NOT NULL,
                note TEXT
            );
        """;

        try (Connection conn = getConnection();
             Statement st = conn.createStatement()) {
            st.execute(sql);
            System.out.println("Database initialized at " + URL);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

package com.expense.dao;

import com.expense.db.DatabaseManager;
import com.expense.model.Expense;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for expenses table.
 */
public class ExpenseDAO {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    public void insert(Expense e) throws SQLException {
        String sql = "INSERT INTO expenses(category, amount, timestamp, note) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, e.getCategory());
            ps.setDouble(2, e.getAmount());
            ps.setString(3, e.getTimestamp().format(FMT));
            ps.setString(4, e.getNote());
            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    e.setId(rs.getInt(1));
                }
            }
        }
    }

    public List<Expense> getAll() throws SQLException {
        List<Expense> list = new ArrayList<>();
        String sql = "SELECT id, category, amount, timestamp, note FROM expenses ORDER BY timestamp DESC";

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Expense e = new Expense();
                e.setId(rs.getInt("id"));
                e.setCategory(rs.getString("category"));
                e.setAmount(rs.getDouble("amount"));
                e.setTimestamp(LocalDateTime.parse(rs.getString("timestamp"), FMT));
                e.setNote(rs.getString("note"));
                list.add(e);
            }
        }

        return list;
    }

    /**
     * Monthly summary grouped by category (for pie chart).
     */
    public List<MonthlySummary> getMonthlySummary(int year, int month) throws SQLException {
        List<MonthlySummary> list = new ArrayList<>();
        String sql = """
            SELECT category, SUM(amount) AS total
            FROM expenses
            WHERE strftime('%Y', timestamp) = ? AND strftime('%m', timestamp) = ?
            GROUP BY category
        """;

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, String.format("%04d", year));
            ps.setString(2, String.format("%02d", month));

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new MonthlySummary(
                            rs.getString("category"),
                            rs.getDouble("total")
                    ));
                }
            }
        }
        return list;
    }

    /**
     * Saving vs Spending summary (for bar chart).
     */
    public SavingSpendingSummary getSavingVsSpending(int year, int month) throws SQLException {
        String sql = """
            SELECT category, SUM(amount) AS total
            FROM expenses
            WHERE strftime('%Y', timestamp) = ? 
              AND strftime('%m', timestamp) = ?
              AND category IN ('Saving', 'Spend')
            GROUP BY category
        """;

        double saving = 0.0;
        double spending = 0.0;

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, String.format("%04d", year));
            ps.setString(2, String.format("%02d", month));

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String cat = rs.getString("category");
                    double total = rs.getDouble("total");
                    if ("Saving".equalsIgnoreCase(cat)) {
                        saving = total;
                    } else if ("Spend".equalsIgnoreCase(cat)) {
                        spending = total;
                    }
                }
            }
        }
        return new SavingSpendingSummary(saving, spending);
    }

    // Helper DTO classes
    public static class MonthlySummary {
        public final String category;
        public final double total;

        public MonthlySummary(String category, double total) {
            this.category = category;
            this.total = total;
        }
    }

    public static class SavingSpendingSummary {
        public final double saving;
        public final double spending;

        public SavingSpendingSummary(double saving, double spending) {
            this.saving = saving;
            this.spending = spending;
        }
    }
}

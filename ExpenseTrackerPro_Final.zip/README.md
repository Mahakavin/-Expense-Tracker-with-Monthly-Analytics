# Expense Tracker (Java + Swing + SQLite + JFreeChart + PDFBox)

A desktop Expense Tracker application built in Java using Swing for the UI, SQLite for data storage,
JFreeChart for analytics, and Apache PDFBox for PDF export.

## Features

- Add expenses with:
  - Category (Saving, Spend, Food, Travel, Other)
  - Amount
  - Note
  - Timestamp (auto-generated)
- View all expenses in a JTable.
- **Analytics**:
  - Monthly **Pie Chart** of expenses by category.
  - Monthly **Bar Chart** of Saving vs Spend.
- **Export**:
  - Export all expenses to **CSV** (`exports/expenses.csv`).
  - Export all expenses to **PDF** (`exports/expenses.pdf`) using PDFBox.
- Uses **SQLite** so no external DB server is needed.

## Project Structure

```
ExpenseTracker/
  ├── src/
  │   ├── com/expense/Main.java
  │   ├── com/expense/db/DatabaseManager.java
  │   ├── com/expense/dao/ExpenseDAO.java
  │   ├── com/expense/model/Expense.java
  │   └── com/expense/ui/MainFrame.java
  ├── data/
  │   └── expenses.db  (auto-created at runtime if not present)
  ├── exports/
  │   ├── expenses.csv
  │   └── expenses.pdf
  ├── screenshots/     (you can capture and store UI images here)
  ├── lib/             (put external JARs here)
  ├── README.md
  └── project_report.pdf
```

## Dependencies

Add these libraries to your classpath (put JARs inside `lib/` and add them in your IDE):

- SQLite JDBC driver (`sqlite-jdbc`)
- JFreeChart (`jfreechart`, usually also `jcommon`)
- Apache PDFBox:
  - `pdfbox`
  - `fontbox`

## How to Run

1. Install Java (JDK 8+).
2. Download the required JARs and place them in the `lib/` folder.
3. Open the project in an IDE (IntelliJ / Eclipse / NetBeans).
4. Mark `src/` as a source folder.
5. Add all JARs from `lib/` to the project classpath.
6. Run the `com.expense.Main` class.

The main window will open. From there you can:
- Add expenses,
- View them in the table,
- Generate monthly Pie/Bar charts,
- Export CSV/PDF files.

## Notes

- The SQLite database file `data/expenses.db` is created automatically.
- If you move the project, keep the `data/` and `exports/` directories alongside the JAR.
